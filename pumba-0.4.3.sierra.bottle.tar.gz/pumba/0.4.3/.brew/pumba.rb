require "language/go"

class Pumba < Formula
  desc "Chaos testing tool for Docker"
  homepage "https://github.com/gaia-adm/pumba"
  version "0.4.3"
  url "https://github.com/gaia-adm/pumba/archive/0.4.3.tar.gz"
  sha256 "eba3d0d66944cd408348f52df5cc7c767414261a3104c6c868c5a1ac761c376d"
  head "https://github.com/gaia-adm/pumba.git"

  depends_on "go" => :build
  depends_on "glide" => :build

  def install
    ENV["GOPATH"] = buildpath
    ENV["GLIDE_HOME"] = HOMEBREW_CACHE/"glide_home/#{name}"
    ENV["CGO_ENABLED"] = "0"

    ENV["GOPATH"] = buildpath
    ENV["GLIDE_HOME"] = HOMEBREW_CACHE/"glide_home/#{name}"
    pumbapath = buildpath/"src/github.com/gaia-adm/pumba"
    pumbapath.install Dir["{*,.git}"]

    ldflags = "-X main.Version=#{version} -X main.GitCommit=02cc3fb3c5eb79adaa922799e346590495d6c35e -X main.GitBranch=master -X main.BuildTime=2017-07-08_09:05_GMTb"

    cd pumbapath do
      system "glide", "install", "-v"
      system "go", "build", "-v", "-o", "dist/pumba", "-ldflags", ldflags
      bin.install "dist/pumba"
    end
  end

  test do
    system "#{bin}/pumba", "--version"
  end
end
